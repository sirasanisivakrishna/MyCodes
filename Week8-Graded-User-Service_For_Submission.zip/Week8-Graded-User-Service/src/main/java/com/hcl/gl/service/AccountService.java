package com.hcl.gl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatchers;
import org.springframework.stereotype.Service;

import com.hcl.gl.pojo.Account;
import com.hcl.gl.repo.AccountRepo;

@Service
public class AccountService 
{

	
	@Autowired
	AccountRepo repo;
	
	
	public void add(Account account) 
	{
		repo.save(account);
	}
	
	public List<Account> getByName(String email)
	{
		Account a1=new Account();
		a1.setEmail(email);
		
		ExampleMatcher em=ExampleMatcher.matching().withMatcher("email", GenericPropertyMatchers.exact()).withIgnorePaths("id","supercoins");
		Example<Account> example=Example.of(a1,em);
		return repo.findAll(example);
		
	}
	
	
	
}
