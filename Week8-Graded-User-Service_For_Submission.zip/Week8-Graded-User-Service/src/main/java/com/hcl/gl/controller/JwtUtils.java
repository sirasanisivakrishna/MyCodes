package com.hcl.gl.controller;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.hcl.gl.pojo.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtils 
{

public static String createtoken(User user) 
{
		
		//time frame
		Calendar date = Calendar.getInstance();
		System.out.println("Current time : " + date.getTime());
		
		long timeInSecs = date.getTimeInMillis();
		Date issuedDate = new Date(timeInSecs);//Starting date //eg: Feb 15, 11:33 AM
		Date expireDate = new Date(timeInSecs + (10*60*1000));//expire date //eg: Feb 15, 11:17 AM
		
		//Create the JWT Step1:
		Claims claims = Jwts.claims().setIssuedAt(issuedDate).setIssuer(String.valueOf(user.getId())).setExpiration(expireDate);
		
		//Step 2 : secret code
		String code = Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS512, "avatar").compact();
		
		return code;
		
	}
	
	public static Claims verifyToken(String code) 
	{
		
		try
		{
			//verify wethern any token is created matching with this code
			Claims claim = Jwts.parser().setSigningKey("avatar").parseClaimsJws(code).getBody();
			return claim;
		}
		catch(Exception ex) 
		{
			return null;
		}
		
	}
	
	
	
}
