package com.hcl.gl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.gl.pojo.Account;
import com.hcl.gl.pojo.User;
import com.hcl.gl.service.AccountService;
import com.hcl.gl.service.UserService;

import io.jsonwebtoken.Claims;


@RestController
public class UserController 
{


	@Autowired
	UserService userService;
	
	@Autowired
	AccountService accountService;
	
	@GetMapping("/Login")
	public String checkLogin(String email,String password)
	{
		String code = userService.loginCheck(email, password);
		
		if(code != null) 
		{
			return "Secret Jwt code : " + code;
		}
		else 
		{
			return "Login Failure";
		}
		
	}
	
	@GetMapping("/checktoken")
	public String checkLogin(String token) 
	{
		Claims c = JwtUtils.verifyToken(token);
		if(c==null) 
		{
			return "NOT OK";
		}
		else 
		{
			//proper token
			return "ok";
		}
	}
	
	//Updating a Product
	@GetMapping("/updateUser")
	public String updateUser(int id,String email, String password) 
	{
		User u1 = new User(id,email, password);
		userService.update(u1);
		return "User password updated successfully";
	}

	
	@GetMapping("/adduser")
	public String add(int id,String email,String password)
	{
		User u2=new User(id, email, password);
	     //List<Account> list=accountService.getByName(email);
	     
	     
		//Account a1=list.get(0);
		//String email1=a1.getEmail();
		Account a2=new Account( email, 100);
		
		userService.adduser(u2);
		accountService.add(a2);
		return "User Registration Done and You Got 100 Super coins to your account";
		
	}
	
	
	@GetMapping("/UserSuperCoins")
	public List<Account> userAccount(String email)
	{
		return accountService.getByName(email);
	}
	
	
	@GetMapping("/userProfilepage")
	public List<User> profile(String email)
	{
		return userService.getByeEmail(email);
	}
	
	
	
}
