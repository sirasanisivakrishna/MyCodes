package com.hcl.gl.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.gl.pojo.Account;

public interface AccountRepo extends JpaRepository<Account, Integer> 
{
	
}
