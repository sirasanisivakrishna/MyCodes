package com.hcl.gl.pojo;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account 
{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	private String email;
	private int supercoins;
	public int getId()
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getEmail() 
	{
		return email;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}
	public int getSupercoins()
	{
		return supercoins;
	}
	public void setSupercoins(int supercoins)
	{
		this.supercoins = supercoins;
	}
	public Account( String email, int supercoins) 
	{
		super();
		this.email = email;
		this.supercoins = supercoins;
	}
	public Account()
	{
	}
	
	
	
	
}
