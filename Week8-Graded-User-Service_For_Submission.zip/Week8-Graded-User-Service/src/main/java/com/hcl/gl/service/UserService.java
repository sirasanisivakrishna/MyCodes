package com.hcl.gl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatchers;
import org.springframework.stereotype.Service;

import com.hcl.gl.controller.JwtUtils;
import com.hcl.gl.pojo.User;
import com.hcl.gl.repo.UserRepo;


@Service
public class UserService {

	@Autowired
	UserRepo repo;
	
	public String loginCheck(String email, String password) 
	{
		
		User userSample = new User();
		userSample.setEmail(email);
		//contains -- good "good morning", "good day", "goodown"
		//exact -- good "good"
		ExampleMatcher em = ExampleMatcher.matching()
				.withMatcher("email", ExampleMatcher.GenericPropertyMatchers.exact()).withIgnorePaths("id","password");
		
		Example<User> example = Example.of(userSample, em);
		
		User user = repo.findAll(example).get(0);//first item(user) from the list
		
		if(user == null) 
		{
			System.out.println("Invalid email address");
			return null;
		}
		else 
		{
			if(user.getPassword().equals(password)) 
			{
				System.out.println("Login Success");
				//jwt concept
				//create a secret code as JWT
				String tokencode = JwtUtils.createtoken(user);
				return tokencode;
			}
			else 
			{
				System.out.println("Login Failure");
				return null;
			}
		}
	}
	
	//This function is used to Update the data into user
 	public void update(User user) 
 	{
 		repo.save(user);
 	}

 	
 	
 	public void adduser(User user)
 	{
 		repo.save(user);
 	}
	
 	
 	
 	public List<User> getByeEmail(String email)
 	{
 		User u1=new User();
 		u1.setEmail(email);
 		ExampleMatcher em=ExampleMatcher.matching().withMatcher("email", GenericPropertyMatchers.exact()).withIgnorePaths("id","password");
 		Example<User> example=Example.of(u1,em);
 		return repo.findAll(example);
 	}
	
}
