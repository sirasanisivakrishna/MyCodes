package com.hcl.gl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week8GradedUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
